# Cook Eat : Livrable 1 : Base de Données

Nous sommes le groupe "Cook Eat" composé de Noa WAROT, Hugo DE BENETTI et Enzo BOTTURA du groupe de TD-G. Cette étape consiste à developper la database sur laquelle reposera notre application Cook Eat.

---

## Contenu du dossier

- **`scripts/`** : Scripts SQL pour créer, peupler et tester la base de données.
  - `CookEat_Create_Tables.sql` : Crée les tables (Schema relationnel).
  - `CookEat_Delete_Tables.sql` : Supprime les tables.
  - `CookEat_Insert_Data.sql` : Importe les données des fichiers CSV.
  - `CookEat_Queries.sql` : Requêtes de test.

- **`data/`** : Fichiers CSV pour peupler les tables.

- **`README.md`** : Instructions pour installer et utiliser la base de données.

---

## Instructions

1. **Ouvrir MySQL Workbench** :
   - Lancez MySQL Workbench et connectez-vous à votre serveur MySQL.

2. **Créer la base de données** :
   - Exécutez :
     ```sql
     CREATE DATABASE nom_de_votre_base;
     USE nom_de_votre_base;
     ```

3. **Exécuter les scripts** :
   - Exécutez dans l'ordre :
     1. `CookEat_Create_Tables.sql` : Crée les tables.
     2. `CookEat_Insert_Data.sql` : Importe les données.
     3. `CookEat_Queries.sql` : Teste la base de données.

4. **Importer les fichiers CSV** :
   - MySQL ne permet d'importer des fichiers que depuis un répertoire spécifique.
   - Pour connaître ce répertoire, exécutez :
     ```sql
     SHOW VARIABLES LIKE 'secure_file_priv';
     ```
   - Déplacez les fichiers CSV du dossier `data/` vers ce répertoire.
   - Si vous obtenez l'erreur `secure_file_priv`, utilisez des chemins absolus dans `populate_tables.sql`. Exemple :
     ```sql
     LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/User_Accounts_Data.csv'
     INTO TABLE user_account
     FIELDS TERMINATED BY ',' 
     ENCLOSED BY '"'
     LINES TERMINATED BY '\n'
     IGNORE 1 ROWS
     (user_id, first_name, last_name, phone_number, email, password, is_business);
     ```

5. **Explorer la base de données** :
   - Utilisez MySQL Workbench pour exécuter des requêtes supplémentaires.

---

## Réinitialisation

Pour tout réinitialiser, exécutez `CookEat_Delete_Tables.sql`, puis recommencez.

---

## Aide

En cas de problème :
- Vérifiez que les fichiers CSV sont dans le bon répertoire.
- Utilisez des chemins absolus si nécessaire.
- Contactez-nous pour plus d'aide.

---

© Cook Eat - 2025