using System.Drawing;
using System.Drawing.Imaging;

namespace Cook_Eat
{
    /// <summary>
    /// Classe s'occupant de la visualisation d'un graphe sous forme d'image.
    /// Permet de dessiner les n�uds et les liens du graphe, avec des options pour le positionnement des n�uds et la coloration.
    /// </summary>
    public class GraphVisualizer
    {
        /// <summary>
        /// Le graphe � visualiser.
        /// </summary>
        private Graph graph;

        /// <summary>
        /// Bitmap utilis� pour dessiner l'image du graphe.
        /// </summary>
        private Bitmap bitmap;

        /// <summary>
        /// Objet Graphics utilis� pour dessiner sur le bitmap.
        /// </summary>
        private Graphics graphics;

        /// <summary>
        /// Largeur de l'image.
        /// </summary>
        private int width;

        /// <summary>
        /// Hauteur de l'image.
        /// </summary>
        private int height;

        /// <summary>
        /// Dictionnaire stockant les positions des n�uds sur l'image.
        /// </summary>
        private Dictionary<Node, PointF> nodePositions;

        /// <summary>
        /// Dictionnaire stockant les couleurs attribu�es � chaque n�ud.
        /// </summary>
        private Dictionary<Node, Brush> nodeColors;

        /// <summary>
        /// Indique si les n�uds doivent �tre positionn�s de mani�re r�guli�re (en cercle) ou al�atoire.
        /// </summary>
        private bool useRegularPositioning;



        /// <summary>
        /// Constructeur de la classe GraphVisualizer.
        /// </summary>
        /// <param name="graph">Le graphe � visualiser.</param>
        /// <param name="useRegularPositioning">True pour positionner les n�uds en cercle, False pour un positionnement al�atoire.</param>
        /// <param name="width">Largeur de l'image.</param>
        /// <param name="height">Hauteur de l'image.</param>
        public GraphVisualizer(Graph graph, bool useRegularPositioning = false, int width = 1600, int height = 1200)
        {
            this.graph = graph;
            this.width = width;
            this.height = height;
            this.useRegularPositioning = useRegularPositioning;

            bitmap = new Bitmap(width, height);
            graphics = Graphics.FromImage(bitmap);

            nodePositions = new Dictionary<Node, PointF>();
            nodeColors = new Dictionary<Node, Brush>();

            AssignRandomColors(); // Attribue des couleurs al�atoires aux n�uds
        }



        /// <summary>
        /// Visualise le graphe en g�n�rant une image et en l'enregistrant � l'emplacement sp�cifi�.
        /// </summary>
        /// <param name="outputPath">Le chemin o� enregistrer l'image.</param>
        public void Visualize(string outputPath)
        {
            CalculateNodePositions(); // Calcule les positions des n�uds
            DrawGraph(); // Dessine le graphe
            SaveImage(outputPath); // Enregistre l'image
            OpenImage(outputPath); // Ouvre l'image
        }


        /// <summary>
        /// Calcule les positions des n�uds sur l'image.
        /// Utilise un positionnement r�gulier (en cercle) ou al�atoire selon la configuration.
        /// </summary>
        private void CalculateNodePositions()
        {
            if (useRegularPositioning)
            {
                CalculateRegularPositions(); // Positionnement en cercle
            }
            else
            {
                CalculateRandomPositions(); // Positionnement al�atoire
            }
        }


        /// <summary>
        /// Calcule des positions al�atoires pour les n�uds, en �vitant les chevauchements.
        /// </summary>
        private void CalculateRandomPositions()
        {
            Random rand = new Random();
            int margin = 50; // Marge pour �viter les bords
            int minDistance = 100; // Distance minimale entre deux n�uds
            int maxAttempts = 50; // Nombre maximal de tentatives pour trouver une position valide

            foreach (var node in graph.Nodes)
            {
                PointF newPos;
                bool validPosition;
                int attempts = 0;

                do
                {
                    newPos = new PointF(rand.Next(margin, width - margin), rand.Next(margin, height - margin));
                    validPosition = true;

                    // V�rifie que la nouvelle position est suffisamment �loign�e des autres n�uds
                    foreach (var existingPos in nodePositions.Values)
                    {
                        if (Distance(newPos, existingPos) < minDistance)
                        {
                            validPosition = false;
                            break;
                        }
                    }
                    attempts++;
                } while (!validPosition && attempts < maxAttempts);

                nodePositions[node] = newPos; // Enregistre la position du n�ud
            }
        }


        /// <summary>
        /// Calcule des positions r�guli�res pour les n�uds, en les pla�ant en cercle.
        /// </summary>
        private void CalculateRegularPositions()
        {
            double angleIncrement = 2 * Math.PI / graph.Nodes.Count; // Angle entre chaque n�ud
            double radius = Math.Min(width, height) / 2.3; // Rayon du cercle
            int centerX = width / 2, centerY = height / 2; // Centre de l'image
            int index = 0;

            foreach (var node in graph.Nodes)
            {
                double angle = index * angleIncrement;
                nodePositions[node] = new PointF(
                    (float)(centerX + radius * Math.Cos(angle)), // Coordonn�e X
                    (float)(centerY + radius * Math.Sin(angle))  // Coordonn�e Y
                );
                index++;
            }
        }


        /// <summary>
        /// Attribue des couleurs al�atoires � chaque n�ud.
        /// </summary>
        private void AssignRandomColors()
        {
            Random rand = new Random();
            foreach (var node in graph.Nodes)
            {
                nodeColors[node] = new SolidBrush(Color.FromArgb(rand.Next(100, 255), rand.Next(100, 255), rand.Next(100, 255)));
            }
        }


        /// <summary>
        /// Dessine le graphe sur l'image.
        /// </summary>
        private void DrawGraph()
        {
            graphics.Clear(Color.White); // Efface l'image avec un fond blanc

            // Dessine les liens
            foreach (var link in graph.Links)
            {
                DrawLink(link);
            }

            // Dessine les n�uds
            foreach (var node in graph.Nodes)
            {
                DrawNode(node);
            }
        }


        /// <summary>
        /// Dessine un n�ud sur l'image.
        /// </summary>
        /// <param name="node">Le n�ud � dessiner.</param>
        private void DrawNode(Node node)
        {
            var position = nodePositions[node];
            int totalNodes = graph.Nodes.Count;
            float nodeSize = Math.Max(20, 80 - totalNodes); // Taille du n�ud en fonction du nombre total de n�uds

            // Dessine le cercle repr�sentant le n�ud
            graphics.FillEllipse(nodeColors[node], position.X - nodeSize / 2, position.Y - nodeSize / 2, nodeSize, nodeSize);

            // Ajoute l'identifiant du n�ud au centre
            string nodeId = node.Id.ToString();
            Font font = new Font("Arial", nodeSize / 3);
            SizeF textSize = graphics.MeasureString(nodeId, font);
            graphics.DrawString(nodeId, font, Brushes.Black, position.X - textSize.Width / 2, position.Y - textSize.Height / 2);
        }


        /// <summary>
        /// Dessine un lien entre deux n�uds.
        /// </summary>
        /// <param name="link">Le lien � dessiner.</param>
        private void DrawLink(Link link)
        {
            var start = nodePositions[link.StartNode];
            var end = nodePositions[link.EndNode];

            if (link.StartNode.Id != link.EndNode.Id)
            {
                // Dessine une ligne pour les liens normaux
                graphics.DrawLine(Pens.Black, start, end);
            }
            else
            {
                // Dessine une boucle pour les liens r�flexifs
                graphics.DrawEllipse(Pens.Black, start.X - 20, start.Y - 20, 80, 80);
            }

            // Ajoute le poids du lien si le graphe est pond�r�
            if (graph.isWeighted)
            {
                var midPoint = new PointF((start.X + end.X) / 2, (start.Y + end.Y) / 2);
                graphics.DrawString(link.Weight.ToString(), new Font("Arial", 10), Brushes.Red, midPoint);
            }

            // Ajoute une fl�che si le graphe est orient�
            if (graph.isDirected)
            {
                DrawArrowhead(start, end);
            }
        }


        /// <summary>
        /// Dessine une fl�che (carr�) � l'extr�mit� d'un lien orient�.
        /// </summary>
        /// <param name="start">Point de d�part du lien.</param>
        /// <param name="end">Point d'arriv�e du lien.</param>
        private void DrawArrowhead(PointF start, PointF end)
        {
            float size = 6; // Taille de la fl�che
            float offset = 28; // Distance entre la fl�che et le n�ud

            float dx = end.X - start.X;
            float dy = end.Y - start.Y;
            float length = (float)Math.Sqrt(dx * dx + dy * dy);

            float squareX = end.X - dx / length * offset - size / 2;
            float squareY = end.Y - dy / length * offset - size / 2;

            // Dessine un carr� pour repr�senter la fl�che
            graphics.FillRectangle(Brushes.Black, squareX, squareY, size, size);
        }


        /// <summary>
        /// Calcule la distance entre deux points.
        /// </summary>
        /// <param name="a">Premier point.</param>
        /// <param name="b">Deuxi�me point.</param>
        /// <returns>La distance entre les deux points.</returns>
        private float Distance(PointF a, PointF b)
        {
            return (float)Math.Sqrt(Math.Pow(a.X - b.X, 2) + Math.Pow(a.Y - b.Y, 2));
        }


        /// <summary>
        /// Enregistre l'image du graphe � l'emplacement sp�cifi�.
        /// </summary>
        /// <param name="filePath">Le chemin o� enregistrer l'image.</param>
        private void SaveImage(string filePath)
        {
            bitmap.Save(filePath, ImageFormat.Png);
        }


        /// <summary>
        /// Ouvre l'image du graphe avec l'application par d�faut.
        /// </summary>
        /// <param name="filePath">Le chemin de l'image � ouvrir.</param>
        private void OpenImage(string filePath)
        {
            if (File.Exists(filePath))
            {
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(filePath) { UseShellExecute = true });
            }
        }
    }
}